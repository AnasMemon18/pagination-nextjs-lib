import React from 'react';
import styles from './styles.scss';

class Pagination extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      activeButton: null,
    };
    this.limit = this.props.limit;
    this.total = this.props.total;
    this.prevLimit = null
    this.initial = 1
  }

  handleClick = (i) => {

    if (i === 'next') {
      const { activeButton } = this.state;
      const { total } = this.props;

      if (activeButton === null) {
        this.setState({ activeButton: 1 });
      }
      else if (activeButton <= total) {
        if (activeButton === this.limit) {
          this.prevLimit = this.limit
          this.initial = this.limit + 1
        }
        this.setState((prevState) => ({ activeButton: prevState.activeButton + 1 }));
      }

    }

    else if (i === 'prev') {
      const { activeButton } = this.state;
      if (activeButton > 1) {
        this.setState((prevState) => ({ activeButton: prevState.activeButton - 1 }));
        if (activeButton <= this.initial) {
          console.log("initial:: ", this.initial)
          this.initial = activeButton - this.limit;
        }
      }

    }

    else if (i === '>>' || i === "last") {
      this.initial = this.total - this.limit
      this.setState((prevState) => ({ activeButton: this.total }));
    }

    else if (i === '<<' || i === "first") {
      this.initial = 1
      this.setState((prevState) => ({ activeButton: 1 }));
    }

    else {
      this.setState({ activeButton: i });
    }

  }

  renderButtons() {
    var { grid, withSpace } = this.props;

    const { activeButton } = this.state;

    const buttons = [];

    var count = 1
    for (var i = this.initial; i <= this.total; i++) {
      if (count <= this.limit && i !== this.total) {
        console.log("total: ", this.total);
        buttons.push(
          <button
            className={`${styles.btnStyle} ${activeButton === i ? styles.activeBtn : ''} ${grid ? styles.gridStyle : ''} ${withSpace? styles.withSpace: ''}`}
            key={i}
            onClick={() => this.handleClick(i)}
          >
            {i}
          </button>
        );
        count++;
      }
      

      if (i === this.limit && this.total > this.limit) {
        buttons.push(
          <button
            className={`${styles.btnStyle} ${grid ? styles.gridStyle : ''} ${withSpace? styles.withSpace: ''}`}
            key="ellipsis"
            disabled
          >
            ...
          </button>
        );
      }

      if (i === this.total) {
        buttons.push(
          <button
            className={`${styles.btnStyle} ${activeButton === this.total ? styles.activeBtn : ''} ${grid ? styles.gridStyle : ''} ${withSpace? styles.withSpace: ''}`}
            key={this.total}
            onClick={() => this.handleClick(this.total)}
          >
            {this.total}
          </button>
        );
      }
    }
    count = 1
    return buttons;
  }

  render() {
    const { next, last } = this.props;
    const { activeButton } = this.state;

    return (
      <div className='main-div'>
        {last ? (
          <button
            className={`${styles.btnStyle} ${activeButton === 'first' ? styles.activeBtn : ''}`}
            onClick={() => this.handleClick('first')}
          >
            First
          </button>
        ) : <button
          className={`${styles.btnStyle} ${activeButton === '<<' ? styles.activeBtn : ''}`}
          onClick={() => this.handleClick('<<')}
        >
          &lt;&lt;
        </button>}


        {next ? (
          <button
            className={`${styles.btnStyle} ${activeButton === 'prev' ? styles.activeBtn : ''}`}
            onClick={() => this.handleClick('prev')}
          >
            Prev
          </button>
        ) : <button
          className={`${styles.btnStyle} ${activeButton === 'prev' ? styles.activeBtn : ''}`}
          onClick={() => this.handleClick('prev')}
        >
          &lt;
        </button>}

        {this.renderButtons()}

        {next ? (
          <button
            className={`${styles.btnStyle} ${activeButton === 'next' ? styles.activeBtn : ''}`}
            onClick={() => this.handleClick('next')}
          >
            Next
          </button>
        ) : <button
          className={`${styles.btnStyle} ${activeButton === 'next' ? styles.activeBtn : ''}`}
          onClick={() => this.handleClick('next')}
        >
          &gt;
        </button>}

        {last ? (
          <button
            className={`${styles.btnStyle} ${activeButton === 'last' ? styles.activeBtn : ''}`}
            onClick={() => this.handleClick('last')}
          >
            Last
          </button>
        ) : <button
          className={`${styles.btnStyle} ${activeButton === '>>' ? styles.activeBtn : ''}`}
          onClick={() => this.handleClick('>>')}
        >
          &gt;&gt;
        </button>}
      </div>
    );
  }
}

export default Pagination;
